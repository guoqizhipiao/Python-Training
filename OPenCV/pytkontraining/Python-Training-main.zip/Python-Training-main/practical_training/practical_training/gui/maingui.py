import tkinter

class maingui:
    def open_top_window(self):
        win = tkinter.Tk()
        win.title("Main GUI Window")
        win.geometry("400x300")
        win.mainloop()