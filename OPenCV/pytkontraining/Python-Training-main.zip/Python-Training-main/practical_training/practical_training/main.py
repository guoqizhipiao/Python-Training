from gui.maingui import maingui


def main():
    win = maingui()
    win.open_top_window()

if __name__ == "__main__":
    main()